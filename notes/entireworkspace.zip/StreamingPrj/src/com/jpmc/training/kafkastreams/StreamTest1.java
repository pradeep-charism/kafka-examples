package com.jpmc.training.kafkastreams;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes.StringSerde;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.KStream;

public class StreamTest1 {
public static void main(String[] args) {
Properties props=new Properties();
props.setProperty(StreamsConfig.APPLICATION_ID_CONFIG	, "file-etl-app");
props.setProperty(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG	, "localhost:9092");
props.setProperty(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, StringSerde.class.getName());
props.setProperty(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, StringSerde.class.getName());

StreamsBuilder builder=new StreamsBuilder();

KStream<String, String> textLines=builder.stream("test-topic-5");
KStream<String, String> upperCaseText=textLines.mapValues(line->{
System.out.println("processing line "+line);	
return line.toUpperCase();

});
upperCaseText.to("test-topic-6");

Topology topogy=builder.build();
KafkaStreams streams=new KafkaStreams(topogy, props);

streams.start();


try {
	Thread.sleep(5*60*1000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
}
